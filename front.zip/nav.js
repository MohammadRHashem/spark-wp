document.addEventListener("DOMContentLoaded", () => {
  const renderNavbar = () => {
    const appContainer = document.querySelector(".app-container");
    if (!appContainer) return;

    const path = window.location.pathname.split("/").pop();
    const active = {
      broadcaster: path === "index.html" || path === "" ? "active" : "",
      abbreviations: path === "abbreviations.html" ? "active" : "",
      groupSaving: path === "group-saving.html" ? "active" : "",
      groupForwarding: path === "group-forwarding.html" ? "active" : "",
      aiForwarding: path === "ai-forwarding.html" ? "active" : "",
      invoices: path === "invoices.html" ? "active" : "",
      pixKeys: path === "pix-keys.html" ? "active" : "",
    };

    const navbarHTML = `
      <header class="main-header">
        <div class="header-content">
            <h1>TRK-Tech Assistant</h1>
            <p>dashboard</p>
        </div>
        
        <div class="exchange-rates-wrapper">
          <div id="usd-brl-rate-container" class="exchange-rate">
              <span>Loading USD...</span>
          </div>
          <div id="usdt-brl-rate-container" class="exchange-rate">
              <span>Loading USDT...</span>
          </div>
        </div>

        <nav class="main-nav">
            <a href="index.html" class="nav-link ${active.broadcaster}">Broadcaster</a>
            <a href="abbreviations.html" class="nav-link ${active.abbreviations}">Abbreviations</a>
            <a href="group-saving.html" class="nav-link ${active.groupSaving}">Group Saving</a>
            <a href="group-forwarding.html" class="nav-link ${active.groupForwarding}">Group Forwarding</a>
            <a href="ai-forwarding.html" class="nav-link ${active.aiForwarding}">AI Forwarding</a>
            <a href="invoices.html" class="nav-link ${active.invoices}">Invoices</a>
            <a href="pix-keys.html" class="nav-link ${active.pixKeys}">PIX Keys</a>
        </nav>
      </header>
    `;
    appContainer.insertAdjacentHTML("afterbegin", navbarHTML);
  };

    const API_BASE_URL = "http://localhost:3000/api";
    const WS_URL = "ws://localhost:3000";

  const renderSingleRate = (container, data, label) => {
    if (!container) return;
    
    if (!data || !data.rate) {
        container.innerHTML = `<span class="rate-label">${label}</span> <span class="rate-value">-</span>`;
        return;
    }

    const updateTime = new Date(data.lastFetched);
    const timeString = updateTime.toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'America/Sao_Paulo'
    });

    container.innerHTML = `
      <span class="rate-label">${label}</span>
      <span class="rate-value">${data.rate.toFixed(4)}</span>
      <span class="rate-time">${timeString}</span>
    `;
  };

  const updateAllRateDisplays = (data) => {
    const usdContainer = document.getElementById("usd-brl-rate-container");
    const usdtContainer = document.getElementById("usdt-brl-rate-container");
    renderSingleRate(usdContainer, data.usd_brl, 'USD/BRL');
    renderSingleRate(usdtContainer, data.usdt_brl, 'USDT/BRL');
  };

  const fetchInitialExchangeRates = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/exchange-rates`);
      if (!response.ok) throw new Error("Failed to fetch initial rates");
      const data = await response.json();
      updateAllRateDisplays(data);
    } catch (error) {
      console.error("Error fetching initial exchange rates:", error);
      const usdContainer = document.getElementById("usd-brl-rate-container");
      const usdtContainer = document.getElementById("usdt-brl-rate-container");
      if(usdContainer) usdContainer.innerHTML = `<span class="rate-label">USD Rate Error</span>`;
      if(usdtContainer) usdtContainer.innerHTML = `<span class="rate-label">USDT Rate Error</span>`;
    }
  };

  const connectWebSocket = () => {
    const socket = new WebSocket(WS_URL);
    socket.onopen = () => {
      console.log("Navbar WebSocket connection established.");
    };
    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'exchange_rate_update') {
          updateAllRateDisplays(data.payload);
        }
      } catch (e) {
        console.error("Error parsing WebSocket message:", e);
      }
    };
    socket.onclose = () => {
      setTimeout(connectWebSocket, 5000);
    };
    socket.onerror = (error) => {
      console.error("Navbar WebSocket error:", error);
    };
  };

  renderNavbar();
  fetchInitialExchangeRates();
  connectWebSocket();
});