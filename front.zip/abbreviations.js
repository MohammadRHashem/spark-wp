document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://localhost:3000/api';
    const elements = {
        tableBody: document.getElementById('abbreviations-table-body'),
        newBtn: document.getElementById('new-abbreviation-btn'),
        modal: document.getElementById('abbreviation-modal'),
        modalTitle: document.getElementById('modal-title'),
        modalForm: document.getElementById('modal-form'),
        modalItemId: document.getElementById('modal-item-id'),
        modalTriggerInput: document.getElementById('modal-trigger-input'),
        modalResponseTextarea: document.getElementById('modal-response-textarea'),
        modalSaveBtn: document.getElementById('modal-save-btn'),
        modalCancelBtn: document.getElementById('modal-cancel-btn'),
    };

    let allAbbreviations = [];

    const fetchAndRender = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/abbreviations`);
            if (!response.ok) throw new Error('Failed to fetch abbreviations');
            allAbbreviations = await response.json();
            renderTable();
        } catch (error) {
            console.error(error);
            elements.tableBody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:red;">Error loading data.</td></tr>`;
        }
    };

    const renderTable = () => {
        elements.tableBody.innerHTML = '';
        if (allAbbreviations.length === 0) {
            elements.tableBody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding: 20px;">No abbreviations created yet.</td></tr>';
            return;
        }
        allAbbreviations.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.trigger}</td>
                <td>${item.response}</td>
                <td>
                    <button class="icon-btn edit-btn" data-id="${item.id}" title="Edit">✏️</button>
                    <button class="icon-btn delete-btn" data-id="${item.id}" title="Delete">🗑️</button>
                </td>
            `;
            elements.tableBody.appendChild(row);
        });
    };

    const openModal = (mode = 'new', itemId = null) => {
        elements.modalForm.reset();
        elements.modalItemId.value = '';
        if (mode === 'edit' && itemId) {
            const item = allAbbreviations.find(a => a.id == itemId);
            if (item) {
                elements.modalTitle.textContent = 'Edit Abbreviation';
                elements.modalItemId.value = item.id;
                elements.modalTriggerInput.value = item.trigger;
                elements.modalResponseTextarea.value = item.response;
            } else {
                alert('Could not find item to edit.');
                return;
            }
        } else {
            elements.modalTitle.textContent = 'New Abbreviation';
        }
        elements.modal.style.display = 'flex';
    };

    const closeModal = () => {
        elements.modal.style.display = 'none';
    };

    elements.newBtn.addEventListener('click', () => openModal('new'));
    elements.modalCancelBtn.addEventListener('click', closeModal);
    elements.modal.addEventListener('click', e => { if (e.target === elements.modal) closeModal(); });

    elements.tableBody.addEventListener('click', (e) => {
        const editBtn = e.target.closest('.edit-btn');
        const deleteBtn = e.target.closest('.delete-btn');
        if (editBtn) {
            openModal('edit', editBtn.dataset.id);
        }
        if (deleteBtn) {
            const id = deleteBtn.dataset.id;
            if (confirm('Are you sure you want to delete this abbreviation?')) {
                fetch(`${API_BASE_URL}/abbreviations/${id}`, { method: 'DELETE' })
                    .then(res => { if (!res.ok) throw new Error('Failed to delete'); return res.json(); })
                    .then(() => fetchAndRender())
                    .catch(err => alert(err.message));
            }
        }
    });

    elements.modalForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const id = elements.modalItemId.value;
        const trigger = elements.modalTriggerInput.value.trim();
        const response = elements.modalResponseTextarea.value.trim();
        const isEditing = !!id;
        const url = isEditing ? `${API_BASE_URL}/abbreviations/${id}` : `${API_BASE_URL}/abbreviations`;
        try {
            const res = await fetch(url, {
                method: isEditing ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ trigger, response }),
            });
            if (!res.ok) throw new Error((await res.json()).error || 'Request failed.');
            await fetchAndRender();
            closeModal();
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    });

    fetchAndRender(); // Initial load
});