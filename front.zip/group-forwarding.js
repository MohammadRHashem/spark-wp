document.addEventListener("DOMContentLoaded", () => {
  const API_BASE_URL = "http://localhost:3000/api";
  const elements = {
    tableBody: document.getElementById("groups-table-body"),
    searchInput: document.getElementById("group-search-input"), // New search input
  };

  let allGroups = [];
  let isUpdating = false;

  const fetchAndRender = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/forwarding-groups`);
      if (!response.ok) throw new Error("Failed to fetch groups");
      allGroups = await response.json();
      renderTable(allGroups); // Render with all groups initially
    } catch (error) {
      console.error(error);
      elements.tableBody.innerHTML = `<tr><td colspan="2" style="text-align:center;color:red;">Error loading group data.</td></tr>`;
    }
  };

  const renderTable = (groupsToRender) => {
    elements.tableBody.innerHTML = "";
    if (groupsToRender.length === 0) {
      elements.tableBody.innerHTML =
        '<tr><td colspan="2" style="text-align:center; padding: 20px;">No groups found.</td></tr>';
      return;
    }
    groupsToRender.forEach((group) => {
      const row = document.createElement("tr");
      const isChecked = group.is_forwarding_enabled ? "checked" : "";
      
      row.innerHTML = `
        <td>${group.subject}</td>
        <td>
          <label class="switch">
            <input type="checkbox" class="forwarding-toggle" data-group-id="${group.id}" ${isChecked}>
            <span class="slider round"></span>
          </label>
        </td>
      `;
      elements.tableBody.appendChild(row);
    });
  };

  const handleToggleChange = async (event) => {
    if (isUpdating) return;
    isUpdating = true;

    const checkbox = event.target;
    const groupId = checkbox.dataset.groupId;
    const isEnabled = checkbox.checked;

    try {
      const response = await fetch(`${API_BASE_URL}/forwarding-groups/${groupId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_forwarding_enabled: isEnabled }),
      });
      if (!response.ok) {
        throw new Error("Failed to update status.");
      }
      // Update the state in the allGroups array
      const groupInState = allGroups.find(g => g.id === groupId);
      if (groupInState) {
          groupInState.is_forwarding_enabled = isEnabled;
      }

    } catch (error) {
      console.error(error);
      alert("Error updating forwarding status. Reverting change.");
      checkbox.checked = !isEnabled;
    } finally {
      isUpdating = false;
    }
  };
  
  elements.tableBody.addEventListener('change', (e) => {
      if (e.target.matches('.forwarding-toggle')) {
          handleToggleChange(e);
      }
  });

  // --- NEW: Event listener for the search input ---
  elements.searchInput.addEventListener('input', (e) => {
      const searchTerm = e.target.value.toLowerCase();
      const filteredGroups = allGroups.filter(group => 
          group.subject.toLowerCase().includes(searchTerm)
      );
      renderTable(filteredGroups);
  });

  fetchAndRender();
});