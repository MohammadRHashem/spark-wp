document.addEventListener("DOMContentLoaded", () => {
  // --- CONFIGURATION ---
  const API_BASE_URL = "http://localhost:3000/api";
  const WS_URL = "ws://localhost:3000";

  // --- DOM ELEMENT REFERENCES ---
  const elements = {
    // Groups Panel
    groupListContainer: document.getElementById("group-list"),
    groupListLoader: document.getElementById("group-list-loader"),
    groupSearchInput: document.getElementById("group-search"),
    refreshGroupsBtn: document.getElementById("refresh-groups-btn"),
    selectAllLink: document.getElementById("select-all-groups"),
    deselectAllLink: document.getElementById("deselect-all-groups"),

    // Batch Controls
    batchSearchInput: document.getElementById("batch-search-input"),
    batchDropdownList: document.getElementById("batch-dropdown-list"),
    saveBatchBtn: document.getElementById("save-batch-btn"),
    editBatchBtn: document.getElementById("edit-batch-btn"),
    deleteBatchBtn: document.getElementById("delete-batch-btn"),
    editBatchNameBtn: document.getElementById("edit-batch-name-btn"),

    // Compose Panel
    messageSearchInput: document.getElementById("message-search-input"),
    messageDropdownList: document.getElementById("message-dropdown-list"),
    customMessageTextarea: document.getElementById("custom-message"),
    newTemplateBtn: document.getElementById("new-template-btn"),
    editTemplateBtn: document.getElementById("edit-template-btn"),
    deleteTemplateBtn: document.getElementById("delete-template-btn"),
    templateEditButtons: document.getElementById("template-edit-buttons"),

    // Action Panel
    broadcastForm: document.getElementById("broadcast-form"),
    statusMessage: document.getElementById("status-message"),
    sendBtn: document.getElementById("send-btn"),
    btnText: document.querySelector("#send-btn .btn-text"),
    btnSpinner: document.querySelector("#send-btn .btn-spinner"),

    // Template Modal
    modal: document.getElementById("template-modal"),
    modalTitle: document.getElementById("modal-title"),
    modalForm: document.getElementById("modal-form"),
    modalTemplateId: document.getElementById("modal-template-id"),
    modalTemplateTitle: document.getElementById("modal-template-title"),
    modalTemplateMessage: document.getElementById("modal-template-message"),
    cancelModalBtn: document.getElementById("cancel-modal-btn"),
  };

  // --- STATE MANAGEMENT ---
  let allGroups = [];
  let allMessages = [];
  let allBatches = [];
  let selectedGroupIds = new Set();
  let currentBatchId = null;

  // --- NEW: Reusable Searchable Dropdown Logic ---
  const createSearchableDropdown = (inputEl, listEl, data, displayField, onSelect) => {
    const renderList = (items) => {
      listEl.innerHTML = '';
      if (items.length === 0) {
        listEl.innerHTML = '<div class="searchable-dropdown-item no-results">No results found</div>';
        return;
      }
      items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'searchable-dropdown-item';
        div.textContent = item[displayField];
        div.dataset.id = item.id;
        div.addEventListener('click', () => {
          inputEl.value = item[displayField];
          inputEl.dataset.selectedId = item.id;
          listEl.style.display = 'none';
          onSelect(item);
        });
        listEl.appendChild(div);
      });
    };

    inputEl.addEventListener('input', () => {
      const searchTerm = inputEl.value.toLowerCase();
      const filteredData = data.filter(item => item[displayField].toLowerCase().includes(searchTerm));
      renderList(filteredData);
      listEl.style.display = 'block';
    });

    inputEl.addEventListener('focus', () => {
      renderList(data);
      listEl.style.display = 'block';
    });

    // Clear selection logic
    inputEl.addEventListener('change', () => {
      if (inputEl.value.trim() === '') {
        inputEl.dataset.selectedId = '';
        onSelect(null);
      }
    });

    document.addEventListener('click', (e) => {
      if (!inputEl.contains(e.target) && !listEl.contains(e.target)) {
        listEl.style.display = 'none';
      }
    });
  };


  // --- WEBSOCKET CONNECTION ---
  function connectWebSocket() {
    const socket = new WebSocket(WS_URL);

    socket.onopen = () => {
      console.log("WebSocket connection established.");
      elements.statusMessage.textContent = "Connected. Ready to send.";
      elements.statusMessage.style.color = "var(--secondary-color)";
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "groups_updated") {
        console.log("Group list update received. Fetching new list.");
        fetchGroups();
      } else if (data.type === "status_update") {
        elements.statusMessage.textContent = data.message;
        elements.statusMessage.style.color =
          data.color || "var(--primary-color)";
        if (data.final) {
          elements.sendBtn.disabled = false;
          elements.btnText.style.display = "block";
          elements.btnSpinner.style.display = "none";
        }
      }
    };

    socket.onclose = () => {
      console.log(
        "WebSocket connection closed. Attempting to reconnect in 5 seconds..."
      );
      elements.statusMessage.textContent = "Connection lost. Reconnecting...";
      elements.statusMessage.style.color = "red";
      setTimeout(connectWebSocket, 5000);
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
      elements.statusMessage.textContent = "Connection error.";
      elements.statusMessage.style.color = "red";
    };
  }

  // --- DATA FETCHING & RENDERING ---
  const fetchGroups = async () => {
    showGroupLoader(true);
    try {
      const response = await fetch(`${API_BASE_URL}/groups`);
      if (!response.ok) throw new Error("Network response was not ok");
      allGroups = await response.json();
      renderGroups(allGroups);
    } catch (error) {
      console.error("Error fetching groups:", error);
      elements.groupListContainer.innerHTML = `<p class="error" style="text-align:center;color:red;padding:20px;">Failed to load groups. Is the server running?</p>`;
    } finally {
      showGroupLoader(false);
    }
  };

  const fetchMessages = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/messages`);
      allMessages = await response.json();
      // Initialize the searchable dropdown for messages
      createSearchableDropdown(elements.messageSearchInput, elements.messageDropdownList, allMessages, 'title', handleMessageSelect);
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const fetchBatches = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/batches`);
      allBatches = await response.json();
      // Initialize the searchable dropdown for batches
      createSearchableDropdown(elements.batchSearchInput, elements.batchDropdownList, allBatches, 'name', handleBatchSelect);
    } catch (error) {
      console.error("Error fetching batches:", error);
    }
  };

  const renderGroups = (groupsToRender) => {
    const oldScrollTop = elements.groupListContainer.scrollTop;
    elements.groupListContainer.innerHTML = "";
    if (groupsToRender.length === 0) {
      const message = elements.groupSearchInput.value
        ? "No groups match your search."
        : "No groups found. Try the Refresh button.";
      elements.groupListContainer.innerHTML = `<p class="info" style="text-align:center; padding: 20px;">${message}</p>`;
    }
    groupsToRender.forEach((group) => {
      const item = document.createElement("div");
      item.className = "group-item";
      const isChecked = selectedGroupIds.has(group.id) ? "checked" : "";
      item.innerHTML = `<input type="checkbox" name="groups" value="${group.id}" id="group-${group.id}" ${isChecked}><label for="group-${group.id}">${group.subject}</label>`;
      elements.groupListContainer.appendChild(item);
    });
    elements.groupListContainer.scrollTop = oldScrollTop;
  };

  const updateBatchButtonsUI = () => {
    if (currentBatchId) {
      elements.editBatchBtn.style.display = "inline-block";
      elements.deleteBatchBtn.style.display = "inline-block";
      elements.editBatchNameBtn.style.display = "inline-block";
      elements.saveBatchBtn.style.display = "none";
    } else {
      elements.editBatchBtn.style.display = "none";
      elements.deleteBatchBtn.style.display = "none";
      elements.editBatchNameBtn.style.display = "none";
      elements.saveBatchBtn.style.display = "block";
    }
  };

  const showGroupLoader = (show) => {
    if (show) {
      elements.groupListLoader.innerHTML = "";
      for (let i = 0; i < 10; i++) {
        const skeleton = document.createElement("div");
        skeleton.className = "skeleton-item";
        elements.groupListLoader.appendChild(skeleton);
      }
      elements.groupListLoader.style.display = "block";
      elements.groupListContainer.style.display = "none";
    } else {
      elements.groupListLoader.style.display = "none";
      elements.groupListContainer.style.display = "block";
    }
  };

  // --- MODAL HANDLING for Templates ---
  function openTemplateModal(mode = "new", templateId = null) {
    elements.modalForm.reset();
    elements.modalTemplateId.value = "";
    if (mode === "edit" && templateId) {
      const template = allMessages.find((m) => m.id == templateId);
      if (template) {
        elements.modalTitle.textContent = "Edit Message Template";
        elements.modalTemplateId.value = template.id;
        elements.modalTemplateTitle.value = template.title;
        elements.modalTemplateMessage.value = template.message;
      } else {
        alert("Could not find the selected template to edit.");
        return;
      }
    } else {
      elements.modalTitle.textContent = "New Message Template";
    }
    elements.modal.style.display = "flex";
  }

  elements.cancelModalBtn.addEventListener(
    "click",
    () => (elements.modal.style.display = "none")
  );
  elements.modal.addEventListener("click", (e) => {
    if (e.target === elements.modal) elements.modal.style.display = "none";
  });

  elements.modalForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const id = elements.modalTemplateId.value;
    const title = elements.modalTemplateTitle.value.trim();
    const message = elements.modalTemplateMessage.value.trim();
    const isEditing = !!id;
    const url = isEditing
      ? `${API_BASE_URL}/messages/${id}`
      : `${API_BASE_URL}/messages`;
    if (!title || !message) {
      alert("Title and message are required.");
      return;
    }
    try {
      const response = await fetch(url, {
        method: isEditing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, message }),
      });
      if (!response.ok) throw new Error((await response.json()).error);
      await fetchMessages();
      elements.modal.style.display = "none";
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  });

  // --- EVENT LISTENERS & HANDLERS ---
  const handleBatchSelect = (batch) => {
    currentBatchId = batch ? batch.id : null;
    selectedGroupIds.clear();
    if (currentBatchId) {
      const selectedBatch = allBatches.find((b) => b.id == currentBatchId);
      if (selectedBatch) {
        selectedGroupIds = new Set(selectedBatch.groups);
      }
    }
    if (!batch) { // Clear input if deselected
        elements.batchSearchInput.value = '';
    }
    renderGroups(allGroups);
    updateBatchButtonsUI();
  };

  const handleMessageSelect = (message) => {
    if (message) {
      elements.customMessageTextarea.value = message.message || "";
      elements.templateEditButtons.style.display = "inline-flex";
    } else {
      elements.customMessageTextarea.value = "";
      elements.templateEditButtons.style.display = "none";
    }
  };
  
  elements.editBatchNameBtn.addEventListener("click", async () => {
    if (!currentBatchId) return;
    const currentBatch = allBatches.find((b) => b.id == currentBatchId);
    if (!currentBatch) return alert("Could not find the selected batch.");

    const newName = prompt("Enter the new name for this batch:", currentBatch.name);
    if (!newName || newName.trim() === "" || newName.trim() === currentBatch.name) return;

    try {
      const response = await fetch(`${API_BASE_URL}/batches/${currentBatchId}/name`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName.trim() }),
      });
      if (!response.ok) throw new Error((await response.json()).error || "Failed to update batch name.");
      alert(`Batch name updated to "${newName.trim()}" successfully!`);
      await fetchBatches();
      elements.batchSearchInput.value = newName.trim();
      elements.batchSearchInput.dataset.selectedId = currentBatchId;
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  });

  elements.refreshGroupsBtn.addEventListener("click", async () => {
    elements.refreshGroupsBtn.disabled = true;
    try {
      await fetch(`${API_BASE_URL}/groups/sync`, { method: "POST" });
      alert("Group sync with WhatsApp initiated. The list will update shortly.");
    } catch (error) {
      console.error("Error triggering manual sync:", error);
      alert("Failed to sync groups. Please check the server logs.");
    } finally {
      elements.refreshGroupsBtn.disabled = false;
    }
  });

  elements.groupSearchInput.addEventListener("input", (e) => {
    renderGroups(
      allGroups.filter((g) =>
        g.subject.toLowerCase().includes(e.target.value.toLowerCase())
      )
    );
  });

  elements.groupListContainer.addEventListener("change", (e) => {
    if (e.target.matches('input[type="checkbox"]')) {
      e.target.checked
        ? selectedGroupIds.add(e.target.value)
        : selectedGroupIds.delete(e.target.value);
    }
  });

  elements.selectAllLink.addEventListener("click", (e) => {
    e.preventDefault();
    elements.groupListContainer
      .querySelectorAll('input[type="checkbox"]')
      .forEach((cb) => {
        if (!cb.checked) {
          cb.checked = true;
          selectedGroupIds.add(cb.value);
        }
      });
  });

  elements.deselectAllLink.addEventListener("click", (e) => {
    e.preventDefault();
    selectedGroupIds.clear();
    renderGroups(allGroups);
  });

  elements.saveBatchBtn.addEventListener("click", async () => {
    if (selectedGroupIds.size === 0) return alert("Please select at least one group to save in a new batch.");
    const name = prompt("Enter a name for this new batch:");
    if (!name || name.trim() === "") return;
    try {
      const response = await fetch(`${API_BASE_URL}/batches`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, groupIds: Array.from(selectedGroupIds) }),
      });
      if (!response.ok) throw new Error((await response.json()).error);
      const newBatch = await response.json();
      await fetchBatches();
      elements.batchSearchInput.value = newBatch.name;
      elements.batchSearchInput.dataset.selectedId = newBatch.id;
      currentBatchId = newBatch.id;
      updateBatchButtonsUI();
      alert(`Batch "${name}" saved successfully!`);
    } catch (error) {
      alert(error.message);
    }
  });

  elements.editBatchBtn.addEventListener("click", async () => {
    if (!currentBatchId) return;
    try {
      const response = await fetch(`${API_BASE_URL}/batches/${currentBatchId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ groupIds: Array.from(selectedGroupIds) }),
      });
      if (!response.ok) throw new Error("Failed to update batch.");
      await fetchBatches();
      alert("Batch updated successfully!");
    } catch (error) {
      alert(error.message);
    }
  });

  elements.deleteBatchBtn.addEventListener("click", async () => {
    if (!currentBatchId) return;
    const batchName = elements.batchSearchInput.value;
    if (!confirm(`Are you sure you want to delete the batch "${batchName}"?`)) return;
    try {
      await fetch(`${API_BASE_URL}/batches/${currentBatchId}`, { method: "DELETE" });
      currentBatchId = null;
      elements.batchSearchInput.value = '';
      elements.batchSearchInput.dataset.selectedId = '';
      selectedGroupIds.clear();
      await fetchBatches();
      renderGroups(allGroups);
      updateBatchButtonsUI();
    } catch (error) {
      alert("Failed to delete batch.");
    }
  });

  elements.customMessageTextarea.addEventListener("input", () => {
    elements.messageSearchInput.value = '';
    elements.messageSearchInput.dataset.selectedId = '';
    elements.templateEditButtons.style.display = "none";
  });

  elements.newTemplateBtn.addEventListener("click", () => openTemplateModal("new"));
  elements.editTemplateBtn.addEventListener("click", () => {
    const templateId = elements.messageSearchInput.dataset.selectedId;
    if (templateId) openTemplateModal("edit", templateId);
  });

  elements.deleteTemplateBtn.addEventListener("click", async () => {
    const templateId = elements.messageSearchInput.dataset.selectedId;
    if (!templateId) return alert("Please select a template to delete.");
    const templateTitle = elements.messageSearchInput.value;
    if (!confirm(`Are you sure you want to delete the template "${templateTitle}"?`)) return;
    try {
      const response = await fetch(`${API_BASE_URL}/messages/${templateId}`, { method: "DELETE" });
      if (!response.ok) throw new Error((await response.json()).error);
      alert("Template deleted successfully!");
      elements.customMessageTextarea.value = "";
      elements.messageSearchInput.value = '';
      elements.messageSearchInput.dataset.selectedId = '';
      await fetchMessages();
      elements.templateEditButtons.style.display = "none";
    } catch (error) {
      alert(error.message);
    }
  });

  elements.broadcastForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = elements.customMessageTextarea.value.trim();
    if (selectedGroupIds.size === 0 || !message) {
      alert("Please select at least one group and write a message.");
      return;
    }
    if (!confirm(`You are about to send a message to ${selectedGroupIds.size} group(s). Continue?`)) return;

    elements.sendBtn.disabled = true;
    elements.btnText.style.display = "none";
    elements.btnSpinner.style.display = "block";
    elements.statusMessage.textContent = `Initiating broadcast...`;
    elements.statusMessage.style.color = "var(--primary-color)";

    try {
      const response = await fetch(`${API_BASE_URL}/broadcast`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          groupIds: Array.from(selectedGroupIds),
          message,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
    } catch (error) {
      elements.statusMessage.textContent = `Error: ${error.message}`;
      elements.statusMessage.style.color = "red";
      elements.sendBtn.disabled = false;
      elements.btnText.style.display = "block";
      elements.btnSpinner.style.display = "none";
    }
  });

  // --- INITIALIZATION ---
  connectWebSocket();
  fetchGroups();
  fetchMessages();
  fetchBatches();
  updateBatchButtonsUI();
  elements.templateEditButtons.style.display = "none";
});