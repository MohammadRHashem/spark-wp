document.addEventListener("DOMContentLoaded", () => {
  const API_BASE_URL = "http://localhost:3000/api";
  const elements = {
    tableBody: document.getElementById("rules-table-body"),
    newBtn: document.getElementById("new-rule-btn"),
    modal: document.getElementById("rule-modal"),
    modalTitle: document.getElementById("modal-title"),
    modalForm: document.getElementById("modal-form"),
    modalItemId: document.getElementById("modal-item-id"),
    modalTriggerInput: document.getElementById("modal-trigger-input"),
    modalGroupSearchInput: document.getElementById("modal-group-search-input"),
    modalGroupDropdownList: document.getElementById("modal-group-dropdown-list"),
    modalSaveBtn: document.getElementById("modal-save-btn"),
    modalCancelBtn: document.getElementById("modal-cancel-btn"),
  };

  let allRules = [];
  let allGroups = [];

  // --- NEW: Reusable Searchable Dropdown Logic (scoped to this file) ---
  const createSearchableDropdown = (inputEl, listEl, data, displayField, onSelect) => {
    const renderList = (items) => {
      listEl.innerHTML = '';
      if (items.length === 0) {
        listEl.innerHTML = '<div class="searchable-dropdown-item no-results">No results found</div>';
        return;
      }
      items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'searchable-dropdown-item';
        div.textContent = item[displayField];
        div.dataset.id = item.id;
        div.addEventListener('click', () => {
          inputEl.value = item[displayField];
          inputEl.dataset.selectedId = item.id;
          listEl.style.display = 'none';
          onSelect(item);
        });
        listEl.appendChild(div);
      });
    };

    inputEl.addEventListener('input', () => {
      const searchTerm = inputEl.value.toLowerCase();
      const filteredData = data.filter(item => item[displayField].toLowerCase().includes(searchTerm));
      renderList(filteredData);
      listEl.style.display = 'block';
    });

    inputEl.addEventListener('focus', () => {
      renderList(data);
      listEl.style.display = 'block';
    });

    document.addEventListener('click', (e) => {
      if (!inputEl.contains(e.target) && !listEl.contains(e.target)) {
        listEl.style.display = 'none';
      }
    });
  };

  const fetchRulesAndRender = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/forwarding-rules`);
      if (!response.ok) throw new Error("Failed to fetch forwarding rules");
      allRules = await response.json();
      renderTable();
    } catch (error) {
      console.error(error);
      elements.tableBody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:red;">Error loading data.</td></tr>`;
    }
  };

  const fetchGroups = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/groups`);
      if (!response.ok) throw new Error("Failed to fetch groups");
      allGroups = await response.json();
    } catch (error) {
      console.error(error);
      alert("Could not load WhatsApp groups for the dropdown. Please refresh.");
    }
  };

  const renderTable = () => {
    elements.tableBody.innerHTML = "";
    if (allRules.length === 0) {
      elements.tableBody.innerHTML =
        '<tr><td colspan="3" style="text-align:center; padding: 20px;">No forwarding rules created yet.</td></tr>';
      return;
    }
    allRules.forEach((item) => {
      const row = document.createElement("tr");
      const destinationName =
        item.destination_group_name ||
        `<i style="color: #888;">${item.destination_group_id}</i>`;
      row.innerHTML = `
                <td>${item.trigger_keyword}</td>
                <td>${destinationName}</td>
                <td>
                    <button class="icon-btn edit-btn" data-id="${item.id}" title="Edit">✏️</button>
                    <button class="icon-btn delete-btn" data-id="${item.id}" title="Delete">🗑️</button>
                </td>
            `;
      elements.tableBody.appendChild(row);
    });
  };

  const openModal = (mode = "new", itemId = null) => {
    elements.modalForm.reset();
    elements.modalItemId.value = "";
    elements.modalGroupSearchInput.dataset.selectedId = '';
    
    // Initialize the searchable dropdown inside the modal
    createSearchableDropdown(elements.modalGroupSearchInput, elements.modalGroupDropdownList, allGroups, 'subject', () => {});

    if (mode === "edit" && itemId) {
      const item = allRules.find((r) => r.id == itemId);
      if (item) {
        elements.modalTitle.textContent = "Edit Forwarding Rule";
        elements.modalItemId.value = item.id;
        elements.modalTriggerInput.value = item.trigger_keyword;
        // Pre-fill the searchable input
        const group = allGroups.find(g => g.id === item.destination_group_id);
        if (group) {
            elements.modalGroupSearchInput.value = group.subject;
            elements.modalGroupSearchInput.dataset.selectedId = group.id;
        }
      } else {
        alert("Could not find item to edit.");
        return;
      }
    } else {
      elements.modalTitle.textContent = "New Forwarding Rule";
    }
    elements.modal.style.display = "flex";
  };

  const closeModal = () => {
    elements.modal.style.display = "none";
  };

  elements.newBtn.addEventListener("click", () => openModal("new"));
  elements.modalCancelBtn.addEventListener("click", closeModal);
  elements.modal.addEventListener("click", (e) => {
    if (e.target === elements.modal) closeModal();
  });

  elements.tableBody.addEventListener("click", (e) => {
    const editBtn = e.target.closest(".edit-btn");
    const deleteBtn = e.target.closest(".delete-btn");
    if (editBtn) {
      openModal("edit", editBtn.dataset.id);
    }
    if (deleteBtn) {
      const id = deleteBtn.dataset.id;
      if (confirm("Are you sure you want to delete this forwarding rule?")) {
        fetch(`${API_BASE_URL}/forwarding-rules/${id}`, { method: "DELETE" })
          .then((res) => {
            if (!res.ok) throw new Error("Failed to delete");
            return res.json();
          })
          .then(() => fetchRulesAndRender())
          .catch((err) => alert(err.message));
      }
    }
  });

  elements.modalForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const id = elements.modalItemId.value;
    const trigger_keyword = elements.modalTriggerInput.value.trim();
    const destination_group_id = elements.modalGroupSearchInput.dataset.selectedId;
    const isEditing = !!id;
    const url = isEditing
      ? `${API_BASE_URL}/forwarding-rules/${id}`
      : `${API_BASE_URL}/forwarding-rules`;

    if (!trigger_keyword || !destination_group_id) {
      alert("Please provide a trigger and select a destination group.");
      return;
    }

    try {
      const res = await fetch(url, {
        method: isEditing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trigger_keyword, destination_group_id }),
      });
      if (!res.ok)
        throw new Error((await res.json()).error || "Request failed.");
      await fetchRulesAndRender();
      closeModal();
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  });

  // Initial Load
  fetchGroups();
  fetchRulesAndRender();
});