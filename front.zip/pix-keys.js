document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://localhost:3000/api';
    const elements = {
        tableBody: document.getElementById('pix-keys-table-body'),
        newBtn: document.getElementById('new-pix-key-btn'),
        modal: document.getElementById('pix-key-modal'),
        modalTitle: document.getElementById('modal-title'),
        modalForm: document.getElementById('modal-form'),
        modalItemId: document.getElementById('modal-item-id'),
        modalPixKeyInput: document.getElementById('modal-pix-key-input'),
        modalDescriptionTextarea: document.getElementById('modal-description-textarea'),
        modalForwardingSwitch: document.getElementById('modal-forwarding-switch'),
        modalSaveBtn: document.getElementById('modal-save-btn'),
        modalCancelBtn: document.getElementById('modal-cancel-btn'),
    };

    let allPixKeys = [];

    const fetchAndRender = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/pix-keys`);
            if (!response.ok) throw new Error('Failed to fetch PIX keys');
            allPixKeys = await response.json();
            renderTable();
        } catch (error) {
            console.error(error);
            elements.tableBody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:red;">Error loading data.</td></tr>`;
        }
    };

    const renderTable = () => {
        elements.tableBody.innerHTML = '';
        if (allPixKeys.length === 0) {
            elements.tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding: 20px;">No PIX keys have been added yet.</td></tr>';
            return;
        }
        allPixKeys.forEach(item => {
            const row = document.createElement('tr');
            const statusClass = item.forwarding_enabled ? 'status-enabled' : 'status-disabled';
            const statusText = item.forwarding_enabled ? 'Yes' : 'No';
            
            row.innerHTML = `
                <td>${item.pix_key}</td>
                <td>${item.description || ''}</td>
                <td class="${statusClass}">${statusText}</td>
                <td>
                    <button class="icon-btn edit-btn" data-id="${item.id}" title="Edit">✏️</button>
                    <button class="icon-btn delete-btn" data-id="${item.id}" title="Delete">🗑️</button>
                </td>
            `;
            elements.tableBody.appendChild(row);
        });
    };

    const openModal = (mode = 'new', itemId = null) => {
        elements.modalForm.reset();
        elements.modalItemId.value = '';
        elements.modalForwardingSwitch.checked = true; // Default to checked

        if (mode === 'edit' && itemId) {
            const item = allPixKeys.find(a => a.id == itemId);
            if (item) {
                elements.modalTitle.textContent = 'Edit PIX Key';
                elements.modalItemId.value = item.id;
                elements.modalPixKeyInput.value = item.pix_key;
                elements.modalDescriptionTextarea.value = item.description || '';
                elements.modalForwardingSwitch.checked = !!item.forwarding_enabled;
            } else {
                alert('Could not find item to edit.');
                return;
            }
        } else {
            elements.modalTitle.textContent = 'New PIX Key';
        }
        elements.modal.style.display = 'flex';
    };

    const closeModal = () => {
        elements.modal.style.display = 'none';
    };

    elements.newBtn.addEventListener('click', () => openModal('new'));
    elements.modalCancelBtn.addEventListener('click', closeModal);
    elements.modal.addEventListener('click', e => { if (e.target === elements.modal) closeModal(); });

    elements.tableBody.addEventListener('click', (e) => {
        const editBtn = e.target.closest('.edit-btn');
        if (editBtn) {
            openModal('edit', editBtn.dataset.id);
        }
        
        const deleteBtn = e.target.closest('.delete-btn');
        if (deleteBtn) {
            const id = deleteBtn.dataset.id;
            if (confirm('Are you sure you want to delete this PIX key?')) {
                fetch(`${API_BASE_URL}/pix-keys/${id}`, { method: 'DELETE' })
                    .then(res => { if (!res.ok) throw new Error('Failed to delete'); return res.json(); })
                    .then(() => fetchAndRender())
                    .catch(err => alert(err.message));
            }
        }
    });

    elements.modalForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const id = elements.modalItemId.value;
        const pix_key = elements.modalPixKeyInput.value.trim();
        const description = elements.modalDescriptionTextarea.value.trim();
        const forwarding_enabled = elements.modalForwardingSwitch.checked;
        
        if (!pix_key) {
            alert("PIX Key is required.");
            return;
        }

        const isEditing = !!id;
        const url = isEditing ? `${API_BASE_URL}/pix-keys/${id}` : `${API_BASE_URL}/pix-keys`;
        
        try {
            const res = await fetch(url, {
                method: isEditing ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ pix_key, description, forwarding_enabled }),
            });
            if (!res.ok) throw new Error((await res.json()).error || 'Request failed.');
            await fetchAndRender();
            closeModal();
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    });

    fetchAndRender();
});