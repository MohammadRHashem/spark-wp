document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://localhost:3000/api';
    const WS_URL = 'ws://localhost:3000';

    const elements = {
        tableBody: document.getElementById('invoices-table-body'),
        newBtn: document.getElementById('new-invoice-btn'),
        exportSelect: document.getElementById('export-select'),
        exportCurrentBtn: document.getElementById('export-current-btn'),
        exportFullBtn: document.getElementById('export-full-btn'),
        invoiceSearchInput: document.getElementById('invoice-search'),
        filterHideReview: document.getElementById('filter-hide-review'),
        filterShowReview: document.getElementById('filter-show-review'),
        filterGroup: document.getElementById('filter-group'),
        filterSender: document.getElementById('filter-sender'),
        filterPixKey: document.getElementById('filter-pix-key'),
        filterStartDate: document.getElementById('filter-start-date'),
        filterStartTime: document.getElementById('filter-start-time'),
        filterEndDate: document.getElementById('filter-end-date'),
        filterEndTime: document.getElementById('filter-end-time'),
        clearFiltersBtn: document.getElementById('clear-filters-btn'),
        modal: document.getElementById('invoice-modal'),
        modalTitle: document.getElementById('modal-title'),
        modalForm: document.getElementById('modal-form'),
        modalItemId: document.getElementById('modal-item-id'),
        modalTxIdInput: document.getElementById('modal-txid-input'),
        modalSenderInput: document.getElementById('modal-sender-input'),
        modalRecipientInput: document.getElementById('modal-recipient-input'),
        modalPixKeyInput: document.getElementById('modal-pix-key-input'),
        modalAmountInput: document.getElementById('modal-amount-input'),
        modalSaveBtn: document.getElementById('modal-save-btn'),
        modalCancelBtn: document.getElementById('modal-cancel-btn'),
        sortableHeaders: document.querySelectorAll('th[data-sort-by]'),
    };

    let allInvoices = [];
    let sortBy = 'created_at';
    let sortOrder = 'desc';
    let searchDebounceTimeout;

    const makeTableResizable = () => {
        const table = document.querySelector('.table-container table');
        const headers = Array.from(table.querySelectorAll('th'));
    
        headers.forEach((header) => {
            header.classList.add('resizable');
            const resizer = document.createElement('div');
            resizer.className = 'resizer';
            header.appendChild(resizer);
    
            let x = 0;
            let w = 0;
    
            const mouseDownHandler = (e) => {
                x = e.clientX;
                w = header.offsetWidth;
    
                document.addEventListener('mousemove', mouseMoveHandler);
                document.addEventListener('mouseup', mouseUpHandler);
                resizer.classList.add('resizing');
            };
    
            const mouseMoveHandler = (e) => {
                const dx = e.clientX - x;
                header.style.width = `${w + dx}px`;
            };
    
            const mouseUpHandler = () => {
                document.removeEventListener('mousemove', mouseMoveHandler);
                document.removeEventListener('mouseup', mouseUpHandler);
                resizer.classList.remove('resizing');
            };
    
            resizer.addEventListener('mousedown', mouseDownHandler);
        });
    };
    
    const populateExportSelect = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/pix-keys`);
            if (!response.ok) throw new Error('Failed to fetch PIX keys for export options');
            const pixKeys = await response.json();

            elements.exportSelect.innerHTML = '<option value="" disabled selected>📥 Export by PIX...</option>';
            
            const allOption = document.createElement('option');
            allOption.value = 'all';
            allOption.textContent = 'All (including Internal PIX)';
            elements.exportSelect.appendChild(allOption);

            const allExternalOption = document.createElement('option');
            allExternalOption.value = 'all_external';
            allExternalOption.textContent = 'All (External PIX Only)';
            elements.exportSelect.appendChild(allExternalOption);

            const separator = document.createElement('option');
            separator.disabled = true;
            separator.textContent = '--- By PIX Description ---';
            elements.exportSelect.appendChild(separator);

            pixKeys.forEach(key => {
                if (key.description) {
                    const option = document.createElement('option');
                    option.value = key.pix_key;
                    option.textContent = `${key.description}`;
                    elements.exportSelect.appendChild(option);
                }
            });
        } catch (error) {
            console.error(error);
        }
    };

    const populatePixKeyFilter = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/pix-keys`);
            if (!response.ok) return;
            const keys = await response.json();
            
            const currentValue = elements.filterPixKey.value;
            elements.filterPixKey.innerHTML = '<option value="">All PIX Keys</option>';
            keys.forEach(item => {
                const option = document.createElement('option');
                option.value = item.pix_key;
                option.textContent = item.pix_key;
                elements.filterPixKey.appendChild(option);
            });
            elements.filterPixKey.value = currentValue;
        } catch (error) {
            console.error('Failed to load PIX keys for filter:', error);
        }
    };

    const fetchAndRender = async () => {
        try {
            const params = new URLSearchParams();
            const searchTerm = elements.invoiceSearchInput.value.trim();
            if (searchTerm) {
                params.append('searchTerm', searchTerm);
            }

            if (elements.filterShowReview.checked) params.append('showReviewedOnly', 'true');
            else if (elements.filterHideReview.checked) params.append('hideReviewed', 'true');
            if (elements.filterGroup.value) params.append('groupName', elements.filterGroup.value);
            if (elements.filterSender.value) params.append('senderName', elements.filterSender.value);
            if (elements.filterPixKey.value) params.append('pixKey', elements.filterPixKey.value);
            
            if (elements.filterStartDate.value) {
                const startTime = elements.filterStartTime.value || '00:00:00';
                params.append('startDate', `${elements.filterStartDate.value} ${startTime}`);
            }
            if (elements.filterEndDate.value) {
                const endTime = elements.filterEndTime.value || '23:59:59';
                params.append('endDate', `${elements.filterEndDate.value} ${endTime}`);
            }
            
            params.append('sortBy', sortBy);
            params.append('sortOrder', sortOrder);

            const response = await fetch(`${API_BASE_URL}/invoices?${params.toString()}`);
            if (!response.ok) throw new Error('Failed to fetch invoices');
            allInvoices = await response.json();
            renderTable();
            updateSortUI();
        } catch (error) {
            console.error(error);
            elements.tableBody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:red;">Error loading data.</td></tr>`;
        }
    };

    const populateSelectFilter = async (element, endpoint, defaultOption) => {
        try {
            const response = await fetch(`${API_BASE_URL}/${endpoint}`);
            if (!response.ok) return;
            const items = await response.json();
            const currentValue = element.value;
            element.innerHTML = `<option value="">${defaultOption}</option>`;
            items.forEach(name => {
                const option = document.createElement('option');
                option.value = name;
                option.textContent = name;
                element.appendChild(option);
            });
            element.value = currentValue;
        } catch (error) {
            console.error(`Failed to load filter for ${endpoint}:`, error);
        }
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleString('en-GB', {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
            timeZone: 'America/Sao_Paulo'
        });
    };

    // --- MODIFICATION: Updated renderTable to handle separator rows ---
    const renderTable = () => {
        elements.tableBody.innerHTML = '';
        if (allInvoices.length === 0) {
            elements.tableBody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding: 20px;">No invoices found for the current filters.</td></tr>';
            return;
        }
        allInvoices.forEach(item => {
            const row = document.createElement('tr');

            if (item.status === 'day_separator') {
                row.classList.add('separator-row');
                row.innerHTML = `<td colspan="9">${item.recipient_name || '--- Daily Separator ---'}</td>`;
            } else {
                if (item.is_duplicate) row.classList.add('duplicate-row');

                let txIdCellContent = item.transaction_id || 'N/A';
                if (item.file_path) {
                    const formattedPath = item.file_path.replace(/\\/g, '/');
                    txIdCellContent = `<a href="${API_BASE_URL}/media/${formattedPath}" target="_blank" title="Click to view file">${item.transaction_id || 'View File'}</a>`;
                }
                
                row.innerHTML = `
                    <td>${txIdCellContent}</td>
                    <td>${item.sender_name || 'N/A'}</td>
                    <td>${item.recipient_name || 'N/A'}</td>
                    <td>${item.pix_key || 'N/A'}</td>
                    <td>${item.amount || 'N/A'}</td>
                    <td>${item.group_name || 'DM / Manual'}</td>
                    <td>${formatDate(item.created_at)}</td>
                    <td>${item.status || 'N/A'}</td>
                    <td>
                        <button class="icon-btn edit-btn" data-id="${item.id}" title="Edit">✏️</button>
                        <button class="icon-btn delete-btn" data-id="${item.id}" title="Delete">🗑️</button>
                    </td>
                `;
            }
            elements.tableBody.appendChild(row);
        });
    };
    
    const updateSortUI = () => {
        elements.sortableHeaders.forEach(header => {
            header.classList.remove('asc', 'desc');
            if (header.dataset.sortBy === sortBy) {
                header.classList.add(sortOrder);
            }
        });
    };

    const openModal = (mode = 'new', itemId = null) => {
        elements.modalForm.reset();
        elements.modalItemId.value = '';
        if (mode === 'edit' && itemId) {
            const item = allInvoices.find(a => a.id == itemId);
            if (item) {
                elements.modalTitle.textContent = 'Edit Invoice';
                elements.modalItemId.value = item.id;
                elements.modalTxIdInput.value = item.transaction_id || '';
                elements.modalSenderInput.value = item.sender_name || '';
                elements.modalRecipientInput.value = item.recipient_name || '';
                elements.modalPixKeyInput.value = item.pix_key || '';
                elements.modalAmountInput.value = item.amount || '';
            } else { return alert('Could not find item to edit.'); }
        } else {
            elements.modalTitle.textContent = 'New Invoice';
        }
        elements.modal.style.display = 'flex';
    };
    
    const clearFilters = () => {
        elements.invoiceSearchInput.value = '';
        elements.filterHideReview.checked = false;
        elements.filterShowReview.checked = false;
        elements.filterGroup.value = '';
        elements.filterSender.value = '';
        elements.filterPixKey.value = '';
        elements.filterStartDate.value = '';
        elements.filterStartTime.value = '';
        elements.filterEndDate.value = '';
        elements.filterEndTime.value = '';
        sortBy = 'created_at';
        sortOrder = 'desc';
        fetchAndRender();
    };

    elements.newBtn.addEventListener('click', () => openModal('new'));
    elements.modalCancelBtn.addEventListener('click', () => elements.modal.style.display = 'none');
    elements.modal.addEventListener('click', e => { if (e.target === elements.modal) elements.modal.style.display = 'none'; });
    
    elements.invoiceSearchInput.addEventListener('input', () => {
        clearTimeout(searchDebounceTimeout);
        searchDebounceTimeout = setTimeout(() => {
            fetchAndRender();
        }, 300);
    });
    
    [elements.filterGroup, elements.filterSender, elements.filterStartDate, elements.filterEndDate, elements.filterPixKey, elements.filterStartTime, elements.filterEndTime].forEach(el => {
        const eventType = el.tagName === 'SELECT' ? 'change' : 'input';
        el.addEventListener(eventType, fetchAndRender);
    });

    elements.filterShowReview.addEventListener('change', () => {
        if (elements.filterShowReview.checked) elements.filterHideReview.checked = false;
        fetchAndRender();
    });

    elements.filterHideReview.addEventListener('change', () => {
        if (elements.filterHideReview.checked) elements.filterShowReview.checked = false;
        fetchAndRender();
    });
    
    elements.clearFiltersBtn.addEventListener('click', clearFilters);
    
    elements.sortableHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const newSortBy = header.dataset.sortBy;
            if (sortBy === newSortBy) {
                sortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                sortBy = newSortBy;
                sortOrder = 'desc';
            }
            fetchAndRender();
        });
    });

    elements.tableBody.addEventListener('click', (e) => {
        const editBtn = e.target.closest('.edit-btn');
        if (editBtn) openModal('edit', editBtn.dataset.id);
        
        const deleteBtn = e.target.closest('.delete-btn');
        if (deleteBtn) {
            if (confirm('Are you sure you want to delete this invoice record? This will not delete the media file.')) {
                fetch(`${API_BASE_URL}/invoices/${deleteBtn.dataset.id}`, { method: 'DELETE' })
                    .then(res => { if (!res.ok) throw new Error('Failed to delete'); return res.json(); })
                    .then(fetchAndRender)
                    .catch(err => alert(err.message));
            }
        }
    });

    elements.modalForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const id = elements.modalItemId.value;
        const body = {
            transaction_id: elements.modalTxIdInput.value.trim(),
            sender_name: elements.modalSenderInput.value.trim(),
            recipient_name: elements.modalRecipientInput.value.trim(),
            pix_key: elements.modalPixKeyInput.value.trim(),
            amount: elements.modalAmountInput.value.trim()
        };
        const isEditing = !!id;
        const url = isEditing ? `${API_BASE_URL}/invoices/${id}` : `${API_BASE_URL}/invoices`;
        try {
            const res = await fetch(url, {
                method: isEditing ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            if (!res.ok) throw new Error((await res.json()).error || 'Request failed.');
            await fetchAndRender();
            await populateSelectFilter(elements.filterGroup, 'invoices/groups', 'All Groups');
            await populateSelectFilter(elements.filterSender, 'invoices/senders', 'All Senders');
            elements.modal.style.display = 'none';
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    });
    
    const handleExport = (mode, pixFilterValue = null) => {
        let button = elements.exportFullBtn;
        if (mode === 'current') {
            button = elements.exportCurrentBtn;
        } else if (mode === 'custom') {
            button = elements.exportSelect;
        }

        const originalText = button.innerHTML;
        button.disabled = true;
        if (button.tagName !== 'SELECT') {
            button.innerHTML = 'Exporting...';
        }

        const params = new URLSearchParams();
        params.append('mode', mode);

        if (mode === 'current') {
            const searchTerm = elements.invoiceSearchInput.value.trim();
            if (searchTerm) params.append('searchTerm', searchTerm);
            if (elements.filterShowReview.checked) params.append('showReviewedOnly', 'true');
            else if (elements.filterHideReview.checked) params.append('hideReviewed', 'true');
            if (elements.filterGroup.value) params.append('groupName', elements.filterGroup.value);
            if (elements.filterSender.value) params.append('senderName', elements.filterSender.value);
            if (elements.filterPixKey.value) params.append('pixKey', elements.filterPixKey.value);
            if (elements.filterStartDate.value) {
                const startTime = elements.filterStartTime.value || '00:00:00';
                params.append('startDate', `${elements.filterStartDate.value} ${startTime}`);
            }
            if (elements.filterEndDate.value) {
                const endTime = elements.filterEndTime.value || '23:59:59';
                params.append('endDate', `${elements.filterEndDate.value} ${endTime}`);
            }
            params.append('sortBy', sortBy);
            params.append('sortOrder', sortOrder);
        }

        if (mode === 'custom') {
            params.append('pixFilter', pixFilterValue);
        }

        const exportUrl = `${API_BASE_URL}/invoices/export?${params.toString()}`;
        window.location.href = exportUrl;

        setTimeout(() => {
            button.disabled = false;
            if (button.tagName !== 'SELECT') {
                button.innerHTML = originalText;
            } else {
                button.value = "";
            }
        }, 3000);
    };

    elements.exportSelect.addEventListener('change', () => {
        const selectedValue = elements.exportSelect.value;
        if (selectedValue) {
            handleExport('custom', selectedValue);
        }
    });
    elements.exportCurrentBtn.addEventListener('click', () => handleExport('current'));
    elements.exportFullBtn.addEventListener('click', () => handleExport('full'));

    function connectWebSocket() {
        const socket = new WebSocket(WS_URL);
        socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'invoices_updated') {
                console.log("Invoice update received. Fetching new list and filters.");
                fetchAndRender();
                populateSelectFilter(elements.filterGroup, 'invoices/groups', 'All Groups');
                populateSelectFilter(elements.filterSender, 'invoices/senders', 'All Senders');
                populatePixKeyFilter();
                populateExportSelect();
            }
        };
        socket.onclose = () => { setTimeout(connectWebSocket, 5000); };
        socket.onerror = (error) => { console.error("WebSocket error:", error); };
    }

    // Initial Load
    populatePixKeyFilter();
    populateExportSelect();
    populateSelectFilter(elements.filterGroup, 'invoices/groups', 'All Groups');
    populateSelectFilter(elements.filterSender, 'invoices/senders', 'All Senders');
    fetchAndRender();
    connectWebSocket();
    makeTableResizable();
});